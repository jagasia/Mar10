import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.util.ResourceBundle;
import java.util.Scanner;

public class Main_Transaction {

	public static void main(String[] args) throws Exception{
		ResourceBundle rb = ResourceBundle.getBundle("db");
		String driver, url, username, password;
		driver=rb.getString("driver");
		url=rb.getString("url");
		username=rb.getString("username");
		password=rb.getString("password");
		
		Class.forName(driver);
		Connection con = DriverManager.getConnection(url,username,password);

		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the bid:");
		String bid, bname, bcity;
		bid=sc.nextLine();
		System.out.println("Bname:");
		bname=sc.nextLine();
		System.out.println("Bcity:");
		bcity=sc.nextLine();
		con.setAutoCommit(false);		//
		PreparedStatement st = con.prepareStatement("UPDATE Branch SET bname=?, bcity=? WHERE bid=?");
		st.setString(1, bname);
		st.setString(2, bcity);
		st.setString(3, bid);
		int no=st.executeUpdate();
		System.out.println(no+" row(s) affected");
		System.out.println("Do you want to save changes?(y/n)");
		String choice=sc.next();
		if(choice.equalsIgnoreCase("y"))
			con.commit();
		else
			con.rollback();
		con.close();
		
	}

}
