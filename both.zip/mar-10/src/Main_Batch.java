import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import java.util.Arrays;
import java.util.ResourceBundle;

public class Main_Batch {

	public static void main(String[] args) throws Exception
	{
		ResourceBundle rb = ResourceBundle.getBundle("db");
		String driver, url, username, password;
		driver=rb.getString("driver");
		url=rb.getString("url");
		username=rb.getString("username");
		password=rb.getString("password");
		
		Class.forName(driver);
		Connection con = DriverManager.getConnection(url,username,password);

		Statement st = con.createStatement();
		st.addBatch("INSERT INTO Branch VALUES ('B00015','abcd','efgh')");
		st.addBatch("UPDATE Branch SET bname='Main Branch', BCITY='Pune' WHERE bid='B00011'");
		
		int[] nos = st.executeBatch();
		System.out.println(Arrays.toString(nos));
		con.close();
		
	}

}
