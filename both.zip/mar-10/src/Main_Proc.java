import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.Driver;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.SQLType;
import java.util.ResourceBundle;
import java.util.Scanner;

public class Main_Proc {

	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the employee id:");
		int employeeId=sc.nextInt();
		
		ResourceBundle rb = ResourceBundle.getBundle("db");
		String driver, url, username, password;
		driver=rb.getString("driver");
		url=rb.getString("url");
		username=rb.getString("username");
		password=rb.getString("password");
		
		Class.forName(driver);
		Connection con = DriverManager.getConnection(url,username,password);
		CallableStatement st = con.prepareCall("{call PRCFIND(?,?,?,?)}");
		st.setInt(1, employeeId);
		//we are not supplying 2,3,4 th parameters because they are output parameters
		st.registerOutParameter(2, java.sql.Types.VARCHAR);
		st.registerOutParameter(3, java.sql.Types.VARCHAR);
		st.registerOutParameter(4, java.sql.Types.NUMERIC);
		st.execute();
		//how to get the output values from procedure??? here we go
		String fname, lname;
		int salary;
		fname=st.getString(2);
		lname=st.getString(3);
		salary=st.getInt(4);
		System.out.println(fname);
		System.out.println(lname);
		System.out.println(salary);
	}

}
