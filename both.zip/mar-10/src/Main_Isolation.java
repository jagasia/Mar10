import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.DriverManager;
import java.sql.Statement;
import java.util.ResourceBundle;
import java.util.Scanner;

public class Main_Isolation {

	public static void main(String[] args) throws Exception{
		ResourceBundle rb = ResourceBundle.getBundle("db2");
		String driver, url, username, password;
		driver=rb.getString("driver");
		url=rb.getString("url");
		username=rb.getString("username");
		password=rb.getString("password");
		
		Class.forName(driver);
		Connection con = DriverManager.getConnection(url,username,password);
		con.setAutoCommit(false);
		DatabaseMetaData dbmd = con.getMetaData();
		int ilevel=dbmd.getDefaultTransactionIsolation();
		System.out.println("This connection uses isolation level: "+ilevel);
		con.setTransactionIsolation(Connection.TRANSACTION_SERIALIZABLE);
		//ilevel=dbmd.getDefaultTransactionIsolation();
		ilevel=con.getTransactionIsolation();
		System.out.println("This connection uses isolation level: "+ilevel);
		Statement st = con.createStatement();
		st.executeUpdate("UPDATE Branch SET bname='xyz', bcity='EFGH' WHERE bid='B00015'");
		Scanner sc=new Scanner(System.in);
		System.out.println("Do you want to commit? (y/n)");
		String choice=sc.next();
		if(choice.equalsIgnoreCase("y"))
			con.commit();
		else
			con.rollback();
		con.close();
	}

}
