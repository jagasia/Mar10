import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.ResourceBundle;
import java.util.Scanner;

public class Main_FunctionTask1 {

	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		ResourceBundle rb = ResourceBundle.getBundle("db");
		String driver, url, username, password;
		driver=rb.getString("driver");
		url=rb.getString("url");
		username=rb.getString("username");
		password=rb.getString("password");
		
		Class.forName(driver);
		Connection con = DriverManager.getConnection(url,username,password);
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the acnumber:");
		String acnumber=sc.next();
		CallableStatement st = con.prepareCall("{?= call FNTASK1(?)}");
		st.registerOutParameter(1, java.sql.Types.NUMERIC);
		st.setString(2, acnumber);
		st.execute();
		int balance=st.getInt(1);
		System.out.printf("The acnumber %s has a balance of Rs. %d/-",acnumber, balance);
	}

}
