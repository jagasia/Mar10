import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.ResourceBundle;
import java.util.Scanner;

public class MainProcTask1 {

	public static void main(String[] args) throws SQLException, ClassNotFoundException {
		ResourceBundle rb = ResourceBundle.getBundle("db");
		String driver, url, username, password;
		driver=rb.getString("driver");
		url=rb.getString("url");
		username=rb.getString("username");
		password=rb.getString("password");
		
		Class.forName(driver);
		Connection con = DriverManager.getConnection(url,username,password);
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the acnumber:");
		String acnumber=sc.next();
		CallableStatement st = con.prepareCall("{ call PRCTASK1(?,?,?,?)}");
		st.setString(1, acnumber);
		st.registerOutParameter(2, java.sql.Types.NUMERIC);
		st.registerOutParameter(3, java.sql.Types.NUMERIC);
		st.registerOutParameter(4, java.sql.Types.NUMERIC);
		st.execute();
		int w,d,b;
		w=st.getInt(2);
		d=st.getInt(3);
		b=st.getInt(4);
		System.out.printf("Total withdrawal: %d, deposits: %d and the balance:%d for acnumber:%s\n",w,d,b,acnumber);
	}

}
