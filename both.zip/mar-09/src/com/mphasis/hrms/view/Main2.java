package com.mphasis.hrms.view;

import java.io.File;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;

public class Main2 {

	public static void main(String[] args) throws ParseException {
		Scanner sc=new Scanner(System.in);
		Long associateId;
		String firstName;
		String lastName;
		Date dateOfJoining;
		String gender;
		byte[] picture;
		SimpleDateFormat sdf=new SimpleDateFormat("dd-MMM-yy");
		
		System.out.println("Please provide the values to update an associate");
		System.out.println("Associate Id:(mandatory)");
		associateId=sc.nextLong();
		System.out.println("First Name:(leave blank to keep unchanged)");
		firstName=sc.nextLine();
		if(firstName.equals(""))
			firstName=sc.nextLine();
		System.out.println("Last Name:(leave blank to keep unchanged)");
		lastName=sc.nextLine();
		System.out.println("Date of Joining: (dd-MMM-yy)(leave blank to keep unchanged)");
		String sdate=sc.nextLine();
		if(!sdate.equals(""))
			dateOfJoining=sdf.parse(sdate);
		System.out.println("Gender:(leave blank to keep unchanged)");
		gender=sc.nextLine();
		System.out.println("Picture: (pls enter the full path)(leave blank to keep unchanged)");
		String sFile=sc.nextLine();
		
		
	}

}
