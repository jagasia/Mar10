import java.sql.Connection;
import java.sql.Driver;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;


public class Main_Metadata {

	public static void main(String[] args) throws SQLException {
		Driver driver=new oracle.jdbc.OracleDriver();
		Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1522:XE","sys as sysdba","password");
		Statement st = con.createStatement();
		ResultSet rs = st.executeQuery("SELECT * FROM Employees");
		//this result set has a meta data
		ResultSetMetaData rsmd = rs.getMetaData();
		System.out.printf("There are %d column(s) in this table\n", rsmd.getColumnCount());
		for(int i=1;i<=11;i++)
		{
			System.out.printf("%-10s\t",rsmd.getColumnName(i));
		}
		System.out.println();
		while(rs.next())
		{
			for(int i=1;i<=11;i++)
			{
				System.out.printf("%-10s\t",rs.getString(i));
			}
			System.out.println();
		}
	}

}
