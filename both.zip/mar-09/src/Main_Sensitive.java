import java.sql.Connection;
import java.sql.Driver;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

public class Main_Sensitive {

	public static void main(String[] args) throws SQLException {
		Scanner sc=new Scanner(System.in);
		Driver driver=new oracle.jdbc.driver.OracleDriver();
		Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1522:XE","sys as sysdba","password");
		Statement st = con.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);
//		st.executeUpdate("INSERT INTO Branch VALUES('B00015','One another branch','Kolkata')");
		ResultSet rs = st.executeQuery("SELECT bid, bname, bcity FROM Branch");
		String input="";
		int position=-1;
		do
		{
			System.out.println("ENter the position");
			position=sc.nextInt();
			rs.absolute(position);
			System.out.println("Enter the bname:");
			String bname=sc.nextLine();
			if(bname.equals(""))
				bname=sc.nextLine();
			rs.updateString(2, bname);
			rs.updateRow();
			System.out.println(rs.getString(2));
		}while(position!=-1);
	}

}
