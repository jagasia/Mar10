import java.util.Scanner;

public class Main_Proc {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the employee id:");
		int employeeId=sc.nextInt();
		
	}

}
