import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import oracle.jdbc.driver.OracleDriver;

public class Main {

	public static void main(String[] args) throws SQLException, ClassNotFoundException {
//		OracleDriver driver = new oracle.jdbc.driver.OracleDriver();
		String driverName="oracle.jdbc.driver.OracleDriver";
		Class.forName(driverName);
		String url="jdbc:oracle:thin:@localhost:1522:XE";
		String uid="sys as sysdba";
		String pwd="password";
//		DriverManager.registerDriver(driver);
		Connection con = DriverManager.getConnection(url, uid, pwd);
		Statement st=con.createStatement();
		ResultSet rs = st.executeQuery("SELECT * FROM EMPLOYEES");
		while(rs.next())
			System.out.println(rs.getString(1));
		con.close();
//		DriverManager.deregisterDriver(driver);
	}

}
