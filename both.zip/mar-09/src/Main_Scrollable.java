import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

public class Main_Scrollable {

	public static void main(String[] args) throws SQLException {
		Scanner sc=new Scanner(System.in);
		Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1522:XE","sys as sysdba","password");
		Statement st = con.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);
//		Statement st = con.createStatement(); //forward only, read only result set
		ResultSet rs = st.executeQuery("SELECT bid, bname, bcity FROM Branch");
		while(rs.next())
			System.out.println(rs.getString(2));
		System.out.println("Do you want to iterate in reverse?(y/n)");
		String choice=sc.next();
		if(!choice.equalsIgnoreCase("y"))
			return;
		System.out.println("Reversing...................................");
		while(rs.previous())
			System.out.println(rs.getString(2));
	}

}
